document.getElementById('proceedButton').addEventListener('click', async () => {
    // Get the query value from the input field
    const queryInput = document.getElementById('queryInput').value;
    // if (!queryInput) {
    //     alert('Please enter a query value.');
    //     return;
    // }

    // URL-encode the query value
    // const encodedQuery = encodeURIComponent(queryInput);
    const encodedQuery = encodeURIComponent(queryInput).replace('(', '%28').replace(')', '%29');

    // Show the progress indicator
    const progressContainer = document.getElementById('progress');
    const currentPageElement = document.getElementById('currentPage');
    const agentsCountElement = document.getElementById('agentsCount');
    const totalResultsContainer = document.getElementById('totalResults');
    const totalResultsCountElement = document.getElementById('totalResultsCount');
    progressContainer.style.display = 'block';
    totalResultsContainer.style.display = 'block';

    // Retrieve the auth token from the background script
    const authToken = await getAuthToken();
    if (!authToken) {
        alert('Failed to retrieve auth token');
        progressContainer.style.display = 'none';
        totalResultsContainer.style.display = 'none';
        return;
    }

    // Perform the data extraction
//    const baseUrl = `http://melpaw01.iptel.lifeline.org.au:8080/unifiedconfig/config/agent?q=${encodedQuery}&resultsPerPage=100&page=1`;
    const baseUrl = `http://localhost:8080/unifiedconfig/config/agent?q=${encodedQuery}&resultsPerPage=100&page=1`;
    // const baseUrl = "http://localhost:8080/unifiedconfig/config/agent?q=attributes%3A%28Skill_131114_FC%29&resultsPerPage=100&page=1";
    const allAgents = [];
    let nextPage = baseUrl;
    let pageCount = 1;
    let totalResults = 0;
    let agentsCount = 0;

    while (nextPage) {
        const pageData = await getPageData(nextPage, authToken);
        if (pageData === '') {
            alert('Failed to retrieve data from the server - Aborting process!');
            progressContainer.style.display = 'none';
            totalResultsContainer.style.display = 'none';
            return;
        }
        if (pageData) {
            const xmlData = new DOMParser().parseFromString(pageData, "application/xml");
            totalResults = xmlData.getElementsByTagName('totalResults')[0]?.textContent;
            totalResultsCountElement.textContent = totalResults;
            if (totalResults === '0') {
                alert('No results found for the given query.');
                progressContainer.style.display = 'none';
                totalResultsContainer.style.display = 'none';
                return;
            }
            const agents = xmlData.getElementsByTagName('agent');
            agentsCount += agents.length;
            if (agents.length > 0) {
                for (let agent of agents) {
                    allAgents.push(new XMLSerializer().serializeToString(agent));
                }
            }
            const nextPageElement = xmlData.querySelector('nextPage');
            nextPage = nextPageElement ? nextPageElement.textContent : null;
            pageCount++;
            // Update the current page number
            currentPageElement.textContent = pageCount;
            agentsCountElement.textContent = agentsCount;
        } else {
            nextPage = null;
        }
    }

    // Hide the progress indicator
    progressContainer.style.display = 'none';

    // Create the final XML output
    const finalXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><results><agents>${allAgents.join('\n')}</agents></results>`;

    // Save the data to an XML file
    const xmlBlob = new Blob([finalXml], { type: 'application/xml' });
    const xmlUrl = URL.createObjectURL(xmlBlob);
    const xmlLink = document.createElement('a');
    xmlLink.href = xmlUrl;
    xmlLink.download = 'Cisco-Users-Export.xml';
    document.body.appendChild(xmlLink);
    xmlLink.click();
    document.body.removeChild(xmlLink);
    URL.revokeObjectURL(xmlUrl);

    alert('Data retrieval and saving completed.');

    // Convert XML to CSV
    const csvData = convertXmlToCsv(finalXml);

    // Save the data to a CSV file
    const csvBlob = new Blob([csvData], { type: 'text/csv' });
    const csvUrl = URL.createObjectURL(csvBlob);
    const csvLink = document.createElement('a');
    csvLink.href = csvUrl;
    csvLink.download = 'Cisco-Users-Export.csv';
    document.body.appendChild(csvLink);
    csvLink.click();
    document.body.removeChild(csvLink);
    URL.revokeObjectURL(csvUrl);

    alert('CSV data saved.');
});

async function getAuthToken() {
    return new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({ action: 'getAuthToken' }, (response) => {
            if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
            } else {
                resolve(response.access_token);
            }
        });
    });
}

async function getPageData(url, authToken) {
    const proxyUrl = 'https://melpaw01.iptel.lifeline.org.au/gadgets/makeRequest';
    const params = new URLSearchParams();
    params.append('url', url);
    params.append('httpMethod', 'GET');
    params.append('headers', `Cache-Control=no-cache&Authorization=Bearer ${authToken}`);

    try {
        const response = await fetch(proxyUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: params.toString()
        });
        if (response.ok) {
            const text = await response.text();
            // Remove the initial part of the response
            const jsonString = text.replace('throw 1; < don\'t be evil\' >', '');
            const jsonResponse = JSON.parse(jsonString);
            const xmlBody = jsonResponse[url].body;
            const rc = jsonResponse[url].rc;

            // Check the return code
            if (rc !== 200) {
                if (rc === 401) {
                    alert('Error: Authentication failed. Please refresh your [Cisco CCE Administration] page and try again.');
                    chrome.tabs.create({ url: 'https://melpaw01.iptel.lifeline.org.au/cceadmin/' });
                    return '';
                } else {
                    alert(`Error: Received status code ${rc}.`);
                    return '';
                }
            }

            // Decode the Unicode-encoded XML
            const decodedXml = xmlBody.replace(/\\u([\dA-Fa-f]{4})/g, (match, grp) => {
                return String.fromCharCode(parseInt(grp, 16));
            });
            return decodedXml;
        } else {
            console.error(`Failed to retrieve data from ${url}`);
            return null;
        }
    } catch (error) {
        console.error(`Error retrieving data from ${url}:`, error);
        return null;
    }
}

function convertXmlToCsv(xmlString) {
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(xmlString, "application/xml");
    const agents = xmlDoc.getElementsByTagName('agent');

    // Initialize hashtables to store unique attribute names
    const attributeColumns = {};
    const agentColumns = {};
    const personColumns = {};

    // Iterate through each agent and collect unique attribute names
    for (let agent of agents) {
        // Collect unique agent attributes
        const agentAttributes = agent.getElementsByTagName('agentAttribute');
        for (let attribute of agentAttributes) {
            const attributeName = attribute.getElementsByTagName('attribute')[0].getElementsByTagName('name')[0].textContent;
            if (!attributeColumns[attributeName]) {
                attributeColumns[attributeName] = true;
            }
        }

        // Collect unique agent properties
        for (let child of agent.childNodes) {
            if (child.nodeName !== "agentAttributes" && child.nodeName !== "person") {
                const columnName = child.nodeName;
                if (!agentColumns[columnName]) {
                    agentColumns[columnName] = true;
                }
            }
        }

        // Collect unique person properties
        const person = agent.getElementsByTagName('person')[0];
        for (let child of person.childNodes) {
            const columnName = child.nodeName;
            if (!personColumns[columnName]) {
                personColumns[columnName] = true;
            }
        }
    }

    // Create an array to store the CSV rows
    const csvRows = [];

    // Create the header row
    const headerRow = Object.keys(agentColumns).concat(Object.keys(personColumns)).concat(Object.keys(attributeColumns));
    csvRows.push(headerRow.join(','));

    // Iterate through each agent and create a row for the CSV
    for (let agent of agents) {
        const row = {};

        // Add agent properties to the row
        for (let child of agent.childNodes) {
            if (child.nodeName !== "agentAttributes" && child.nodeName !== "person") {
                const columnName = child.nodeName;
                const columnValue = child.textContent;
                row[columnName] = columnValue;
            }
        }

        // Add person properties to the row
        const person = agent.getElementsByTagName('person')[0];
        for (let child of person.childNodes) {
            const columnName = child.nodeName;
            const columnValue = child.textContent;
            row[columnName] = columnValue;
        }

        // Add agent attributes to the row
        const agentAttributes = agent.getElementsByTagName('agentAttribute');
        for (let attributeName of Object.keys(attributeColumns)) {
            const attributeValue = Array.from(agentAttributes).find(attribute =>
                attribute.getElementsByTagName('attribute')[0].getElementsByTagName('name')[0].textContent === attributeName
            )?.getElementsByTagName('attributeValue')[0]?.textContent || '';
            row[attributeName] = attributeValue;
        }

        // Create the CSV row
        const csvRow = headerRow.map(columnName => row[columnName] || '');
        csvRows.push(csvRow.join(','));
    }

    return csvRows.join('\n');
}
