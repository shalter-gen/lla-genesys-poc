let access_token = null;
let firstRequestIntercepted = false;

chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    // if (!firstRequestIntercepted && details.url.startsWith('https://melpaw01.iptel.lifeline.org.au/gadgets/makeRequest') && details.method === 'POST') {
    if ((details.url.startsWith('https://melpaw01.iptel.lifeline.org.au/gadgets/makeRequest')
      || details.url.startsWith('https://sydpaw01.iptel.lifeline.org.au/gadgets/makeRequest'))
      && details.method === 'POST') {
      // firstRequestIntercepted = true;

      // Decode the form data
      const formData = decodeURIComponent(details.requestBody.formData.headers[0]);

      // Extract the Bearer token
      const bearerTokenMatch = formData.match(/Authorization=Bearer\s+(.+)/);
      if (bearerTokenMatch) {
        access_token = bearerTokenMatch[1];
        chrome.storage.local.set({ access_token: access_token }, () => {
          console.log('Authorization token stored');
        });
      } else {
        console.log('Invalid Bearer token format');
      }
    }
    return { cancel: false };
  },
  { urls: ['https://melpaw01.iptel.lifeline.org.au/gadgets/makeRequest', 'https://sydpaw01.iptel.lifeline.org.au/gadgets/makeRequest']},
  ['requestBody']
);

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getAuthToken') {
    chrome.storage.local.get(['access_token'], (result) => {
      sendResponse({ access_token: result.access_token });
    });
    return true;
  } else if (request.action === 'clearAuthToken') {
    chrome.storage.local.remove('access_token', () => {
      console.log('Authorization token cleared');
      sendResponse({ success: true });
    });
    return true;
  }
});


// Handle the action icon click event
chrome.action.onClicked.addListener((tab) => {
  chrome.storage.local.get(['access_token'], (result) => {
    if (result.access_token) {
      chrome.tabs.create({ url: chrome.runtime.getURL('main.html') });
    } else {
      chrome.tabs.create({ url: 'https://melpaw01.iptel.lifeline.org.au/cceadmin/' });
    }
  });
});